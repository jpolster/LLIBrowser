(function(){
	var app=angular.module('llibrowser',[]);
})();